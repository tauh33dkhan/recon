work="python3 sublist3r.py -d"
while read LINE; do
$work $LINE -t 100
done < alibaba
