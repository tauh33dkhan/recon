import sys
import urllib
from bs4 import BeautifulSoup
import re

domain = sys.argv[1]
file = '/root/tools/wayback/reports/' + domain
report = open(file, 'w')
report.write('[+] Wayback Machine Archived Url')
target = sys.argv[1]
url = "http://web.archive.org/cdx/search/cdx?url=https://"+target+"/*&output=text&f1=original&collapse=urlkey" 
print "[+] Collecting Url's From Wayback Machine for domain" 
query = urllib.urlopen(url)
soup = BeautifulSoup(query, 'html.parser')
str_data = str(soup)
data = re.findall(r'(https?://\S+)',str_data)
for urls in data:
	print urls
	report.write(str(urls) + '\n')

